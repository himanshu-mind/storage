package com.zxc.demos;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.linkedin.android.spyglass.suggestions.SuggestionsResult;
import com.linkedin.android.spyglass.tokenization.QueryToken;
import com.linkedin.android.spyglass.tokenization.interfaces.QueryTokenReceiver;
import com.linkedin.android.spyglass.ui.RichEditorView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DemoActivity extends AppCompatActivity implements QueryTokenReceiver {

    private static final String BUCKET = "persons";

    private RichEditorView editor;
    private List<Person> mList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);

        getPersons();

        editor = findViewById(R.id.editor);
        editor.displayTextCounter(false);
        editor.setQueryTokenReceiver(this);
        editor.setHint("Type here...");

    }

    public void getPersons() {
        mList.clear();
        mList.add(new Person("Justin", "Denim"));
        mList.add(new Person("Andrew", "Cole"));
        mList.add(new Person("Nicole", "Grammar"));
        mList.add(new Person("Harry", "Potter"));
        mList.add(new Person("Ron", "Weisley"));
    }

    @Override
    public List<String> onQueryReceived(@NonNull QueryToken queryToken) {
        List<Person> suggestions = getSuggestions(queryToken);
        SuggestionsResult result = new SuggestionsResult(queryToken, suggestions);
        editor.onReceiveSuggestionsResult(result, BUCKET);
        return Collections.singletonList(BUCKET);
    }

    public List<Person> getSuggestions(QueryToken queryToken) {
        String[] namePrefixes = queryToken.getKeywords().toLowerCase().split(" ");
        List<Person> suggestions = new ArrayList<>();
        if (mList != null) {
            for (Person suggestion : mList) {
                String firstName = suggestion.getFirstName().toLowerCase();
                String lastName = suggestion.getLastName().toLowerCase();
                if (namePrefixes.length == 2) {
                    if (firstName.startsWith(namePrefixes[0]) && lastName.startsWith(namePrefixes[1])) {
                        suggestions.add(suggestion);
                    }
                } else {
                    if (firstName.startsWith(namePrefixes[0]) || lastName.startsWith(namePrefixes[0])) {
                        suggestions.add(suggestion);
                    }
                }
            }
        }
        return suggestions;
    }
}
