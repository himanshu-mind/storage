package com.ansh.editordemo

import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.chinalwb.are.styles.toolitems.ARE_ToolItem_Bold
import com.chinalwb.are.styles.toolitems.ARE_ToolItem_ListNumber
import com.chinalwb.are.styles.toolitems.ARE_ToolItem_Record
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.row_recording_item.*
import java.io.File


class MainActivity : AppCompatActivity() {

    lateinit var recordingPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val file = File(filesDir, "recording.mp3")
        recordingPath = file.absolutePath
        if (file.exists()) file.delete()
        initToolbar()
        showRecording()
    }

    private fun initToolbar() {
        val bold = ARE_ToolItem_Bold()
        val listNumber = ARE_ToolItem_ListNumber()
        val record = ARE_ToolItem_Record()

        areToolbar.addToolbarItem(bold)
        areToolbar.addToolbarItem(listNumber)
        areToolbar.addToolbarItem(record)

        arEditText.setToolbar(areToolbar)

        record.addRecordClickListener { record() }
    }

    private fun showRecording() {
        val file = File(recordingPath)
        if (file.exists()) {
            layoutRecording.visibility = View.VISIBLE

            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(this, Uri.parse(recordingPath))
            val durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)

            tvDur.text = Utils.getMinSecStr(durationStr.toLong())

            ivPlay.setOnClickListener { playPause() }
            ivDelete.setOnClickListener {
                File(recordingPath).delete()
                showRecording()
            }

        } else {
            layoutRecording.visibility = View.GONE
        }
    }

    /* PLAY PAUSE RECORDING */
    private var player: Player = Player()

    private fun playPause() {
        player.start(recordingPath) {
            when (it) {
                PlayerEnum.Playing -> {
                    ivPlay.background = ContextCompat.getDrawable(this, R.drawable.ic_pause)
                }
                PlayerEnum.Paused, PlayerEnum.Completed -> {
                    ivPlay.background = ContextCompat.getDrawable(this, R.drawable.ic_play)
                }
            }
        }
    }

    /* RECORDER */

    lateinit var myAudioRecorder: MediaRecorder
    var time = 0L

    private fun record() {
        Toast.makeText(this, "Recording Started...", Toast.LENGTH_SHORT).show()

        time = 0
        tvDuration.text = ""
        audioRecordView.recreate()

        areToolbar.visibility = View.GONE
        llRecord.visibility = View.VISIBLE

        myAudioRecorder = MediaRecorder()
        myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
        myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB)
        myAudioRecorder.setOutputFile(recordingPath)

        myAudioRecorder.prepare()
        myAudioRecorder.start()

        audioRecordView.update(myAudioRecorder.maxAmplitude)
        timer.start()
    }

    private val timer = object : CountDownTimer(2 * 60 * 1000, 200) {
        override fun onFinish() {
            stopRecording()
        }

        override fun onTick(millisUntilFinished: Long) {
            time += 200
            tvDuration.text = Utils.getMinSecStr(time)
            audioRecordView.update(myAudioRecorder.maxAmplitude)
        }
    }

    private fun stopRecording() {
        myAudioRecorder.stop()
        myAudioRecorder.release()

        timer.cancel()

        areToolbar.visibility = View.VISIBLE
        llRecord.visibility = View.GONE

        showRecording()
    }

    fun done(view: View) {
        stopRecording()
    }
}
