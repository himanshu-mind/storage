package com.ansh.editordemo

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

class MyApp : Application() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var appCtx: Context
    }

    override fun onCreate() {
        super.onCreate()
        appCtx = this
    }

}