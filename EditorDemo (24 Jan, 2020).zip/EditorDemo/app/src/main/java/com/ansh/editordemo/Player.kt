package com.ansh.editordemo

import android.media.MediaPlayer

enum class PlayerEnum {
    Playing, Paused, Completed
}

class Player {

    private var mMediaPlayer: MediaPlayer? = null
    private var mRecordingPath: String = ""
    private var mCallback: ((state: PlayerEnum) -> Unit)? = null

    fun start(recordingPath: String, listener: (state: PlayerEnum) -> Unit) {
        mCallback = listener
        if (mRecordingPath == recordingPath) {
            if (mMediaPlayer != null) {
                if (mMediaPlayer?.isPlaying!!) {
                    pause()
                } else {
                    play()
                }
            } else {
                restart()
            }
        } else {
            mRecordingPath = recordingPath
            restart()
        }
    }

    private fun restart() {
        stop()

        mMediaPlayer = MediaPlayer()
        mMediaPlayer?.setDataSource(mRecordingPath)
        mMediaPlayer?.setOnCompletionListener {
            stop()
            mCallback?.invoke(PlayerEnum.Completed)
        }
        mMediaPlayer?.prepare()

        play()
    }

    private fun play() {
        mMediaPlayer?.start()
        mCallback?.invoke(PlayerEnum.Playing)
    }

    private fun pause() {
        mMediaPlayer?.pause()
        mCallback?.invoke(PlayerEnum.Paused)
    }

    private fun stop() {
        mMediaPlayer?.stop()
        mMediaPlayer?.reset()
        mMediaPlayer = null
    }
}