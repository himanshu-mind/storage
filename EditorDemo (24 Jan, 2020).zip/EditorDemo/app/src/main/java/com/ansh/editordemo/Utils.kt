package com.ansh.editordemo

object Utils {

    fun getMinSecStr(millis: Long): String {
        val minutes = millis / 1000 / 60
        val seconds = (millis / 1000 % 60)
        return String.format(
            "%s:%s",
            if (minutes < 9) "0$minutes" else minutes,
            if (seconds < 9) "0$seconds" else seconds
        )
    }

}