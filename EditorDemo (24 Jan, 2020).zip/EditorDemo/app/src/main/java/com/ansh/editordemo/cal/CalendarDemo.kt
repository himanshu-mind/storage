package com.ansh.editordemo.cal

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.ansh.editordemo.R
import com.calendar.enums.CalendarMode
import com.calendar.view.MaterialCalendarView
import kotlinx.android.synthetic.main.activity_calendar_demo.*

class CalendarDemo : AppCompatActivity() {

    private val oneDayDecorator = OneDayDecorator()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar_demo)

        calendarView.topbarVisible = false
        calendarView.selectionMode = MaterialCalendarView.SELECTION_MODE_SINGLE
        calendarView.addDecorator(oneDayDecorator)
        calendarView.setOnDateChangedListener { _, date, _ ->
            oneDayDecorator.setDate(date.date)
            calendarView.selectedDate = date
            calendarView.addDecorator(oneDayDecorator)
        }

        calendarView.state().edit().setCalendarDisplayMode(CalendarMode.WEEKS).commit()
    }

    fun month(view: View) {
        calendarView.state().edit().setCalendarDisplayMode(CalendarMode.MONTHS).commit()
    }

    fun week(view: View) {
        calendarView.state().edit().setCalendarDisplayMode(CalendarMode.WEEKS).commit()
    }
}
