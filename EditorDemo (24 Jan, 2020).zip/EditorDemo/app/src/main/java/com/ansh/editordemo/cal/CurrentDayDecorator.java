package com.ansh.editordemo.cal;

import android.content.Context;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;

import androidx.core.content.ContextCompat;

import com.calendar.helpers.DayViewFacade;
import com.calendar.interfaces.DayViewDecorator;
import com.calendar.models.CalendarDay;
import com.calendar.spans.DotSpan;
import com.calendar.view.MaterialCalendarView;
import com.calendar.view.R;

import java.util.Date;

/**
 * Decorate a day by making the text big and bold
 */
public class CurrentDayDecorator implements DayViewDecorator {

    private Context context;
    private CalendarDay date;

    public CurrentDayDecorator(Context context) {
        this.context = context;
        date = CalendarDay.today();
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return date != null && day.equals(date);
    }

    @Override
    public void decorate(DayViewFacade view) {
        view.addSpan(new DotSpan(40, ContextCompat.getColor(context, R.color.white)));
        view.addSpan(new ForegroundColorSpan(ContextCompat.getColor(context, R.color.black)));
        view.addSpan(new RelativeSizeSpan(1.0f));
    }

    /**
     * We're changing the internals, so make sure to call {@linkplain MaterialCalendarView#invalidateDecorators()}
     */
    public void setDate(Date date) {
        this.date = CalendarDay.from(date);
    }
}
