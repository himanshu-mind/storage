package com.ansh.editordemo.cal;

import android.text.style.ForegroundColorSpan;

import androidx.core.content.ContextCompat;

import com.ansh.editordemo.MyApp;
import com.ansh.editordemo.R;
import com.calendar.models.CalendarDay;
import com.calendar.interfaces.DayViewDecorator;
import com.calendar.helpers.DayViewFacade;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * Decorate several days with a dot
 */
public class EventDecorator implements DayViewDecorator {

    public static EventDecorator getDefault() {
        List<CalendarDay> dates = new ArrayList<>();
        dates.add(new CalendarDay());
        return new EventDecorator(ContextCompat.getColor(MyApp.appCtx, R.color.colorAccent), dates);
    }

    private int color;
    private HashSet<CalendarDay> dates;

    public EventDecorator(int color, Collection<CalendarDay> dates) {
        this.color = color;
        this.dates = new HashSet<>(dates);
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return dates.contains(day);
    }

    @Override
    public void decorate(DayViewFacade view) {
        view.addSpan(new ForegroundColorSpan(ContextCompat.getColor(MyApp.appCtx, R.color.pictonBlue)));
        //view.addSpan(new DotSpan(22, color));
    }
}
