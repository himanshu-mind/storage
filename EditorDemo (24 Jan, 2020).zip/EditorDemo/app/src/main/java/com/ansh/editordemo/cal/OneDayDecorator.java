package com.ansh.editordemo.cal;

import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;

import androidx.core.content.ContextCompat;

import com.ansh.editordemo.MyApp;
import com.ansh.editordemo.R;
import com.calendar.models.CalendarDay;
import com.calendar.interfaces.DayViewDecorator;
import com.calendar.helpers.DayViewFacade;
import com.calendar.view.MaterialCalendarView;
import com.calendar.spans.DotSpan;

import java.util.Date;

/**
 * Decorate a day by making the text big and bold
 */
public class OneDayDecorator implements DayViewDecorator {

    private CalendarDay date;

    public OneDayDecorator() {
        date = CalendarDay.today();
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return date != null && day.equals(date);
    }

    @Override
    public void decorate(DayViewFacade view) {
        view.addSpan(new DotSpan(40, ContextCompat.getColor(MyApp.appCtx, R.color.black)));
        view.addSpan(new ForegroundColorSpan(ContextCompat.getColor(MyApp.appCtx, R.color.white)));
        view.addSpan(new RelativeSizeSpan(1.0f));
    }

    /**
     * We're changing the internals, so make sure to call {@linkplain MaterialCalendarView#invalidateDecorators()}
     */
    public void setDate(Date date) {
        this.date = CalendarDay.from(date);
    }
}
