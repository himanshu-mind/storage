package com.chinalwb.are.styles.toolbar;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.chinalwb.are.AREditText;
import com.chinalwb.are.R;
import com.chinalwb.are.Util;
import com.chinalwb.are.styles.ARE_Bold;
import com.chinalwb.are.styles.ARE_ListNumber;
import com.chinalwb.are.styles.IARE_Style;

import java.util.ArrayList;
import java.util.List;

/**
 * A fixed toolbar, for including only static tool items.
 * Not friendly for extending.
 * See {@link IARE_Toolbar} and {@link ARE_ToolbarDefault} for more info about dynamic toolbar.
 */
public class ARE_Toolbar extends LinearLayout {

    private Activity mContext;

    private AREditText mEditText;

    private ArrayList<IARE_Style> mStylesList = new ArrayList<>();

    private ARE_Bold mBoldStyle;
    private ARE_ListNumber mListNumberStyle;

    private ImageView mBoldImageView;
    private ImageView mRteListNumber;

    public ARE_Toolbar(Context context) {
        this(context, null);
    }

    public ARE_Toolbar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ARE_Toolbar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = (Activity) context;
        init();
    }

    private void init() {
        LayoutInflater layoutInflater = LayoutInflater.from(this.mContext);
        layoutInflater.inflate(getLayoutId(), this, true);
        this.setOrientation(LinearLayout.VERTICAL);
        initViews();
        initStyles();
        initKeyboard();
    }

    private int getLayoutId() {
        return R.layout.are_toolbar;
    }

    private void initViews() {
        this.mBoldImageView = this.findViewById(R.id.rteBold);
        this.mRteListNumber = this.findViewById(R.id.rteListNumber);
    }

    /**
     *
     */
    private void initStyles() {
        this.mBoldStyle = new ARE_Bold(this.mBoldImageView);
        this.mListNumberStyle = new ARE_ListNumber(this.mRteListNumber, this);

        this.mStylesList.add(this.mBoldStyle);
        this.mStylesList.add(this.mListNumberStyle);
    }

    public void setEditText(AREditText editText) {
        this.mEditText = editText;
        bindToolbar();
    }

    private void bindToolbar() {
        this.mBoldStyle.setEditText(this.mEditText);
    }

    public AREditText getEditText() {
        return this.mEditText;
    }

    public IARE_Style getBoldStyle() {
        return this.mBoldStyle;
    }

    public List<IARE_Style> getStylesList() {
        return this.mStylesList;
    }

    /* -------- START: Keep it at the bottom of the class.. Keyboard and emoji ------------ */
    /* -------- START: Keep it at the bottom of the class.. Keyboard and emoji ------------ */
    private void initKeyboard() {
        final Window window = mContext.getWindow();
        final View rootView = window.getDecorView().findViewById(android.R.id.content);
        rootView.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    public void onGlobalLayout() {
                        if (mLayoutDelay == 0) {
                            init();
                            return;
                        }
                        rootView.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                init();
                            }
                        }, mLayoutDelay);

                    }

                    private void init() {
                        Rect r = new Rect();
                        View view = window.getDecorView();
                        view.getWindowVisibleDisplayFrame(r);
                        int[] screenWandH = Util.getScreenWidthAndHeight(mContext);
                        int screenHeight = screenWandH[1];
                        final int keyboardHeight = screenHeight - r.bottom;

                        if (mPreviousKeyboardHeight != keyboardHeight) {
                            if (keyboardHeight > 100) {
                                mKeyboardHeight = keyboardHeight;
                                onKeyboardShow();
                            } else {
                                onKeyboardHide();
                            }
                        }
                        mPreviousKeyboardHeight = keyboardHeight;
                    }
                });
    }

    private void onKeyboardShow() {
        mKeyboardShownNow = true;
        mEmojiShownNow = false;
        mLayoutDelay = 100;
    }

    private void onKeyboardHide() {
        mKeyboardShownNow = false;
        if (!mHideEmojiWhenHideKeyboard) {
            this.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mHideEmojiWhenHideKeyboard = true;
                }
            }, 100);
        }
    }

    private int mLayoutDelay = 0;
    private int mPreviousKeyboardHeight = 0;
    private boolean mKeyboardShownNow = true;
    private boolean mEmojiShownNow = false;
    private boolean mHideEmojiWhenHideKeyboard = true;
    private int mKeyboardHeight = 0;
    private View mEmojiPanel;

    protected void showKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                view.requestFocus();
                imm.showSoftInput(view, 0);
            }
        }
    }

    public void setEmojiPanel(View emojiPanel) {
        mEmojiPanel = emojiPanel;
    }
    /* -------- END: Keep it at the bottom of the class.. Keyboard and emoji ------------ */
    /* -------- END: Keep it at the bottom of the class.. Keyboard and emoji ------------ */
}
