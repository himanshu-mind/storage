package com.chinalwb.are.styles.toolitems.base;

public interface IARE_ToolItem_Updater {

    void onCheckStatusUpdate(boolean checked);
}
