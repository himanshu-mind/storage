package com.chinalwb.are.styles.toolitems.styles;

import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;

import com.chinalwb.are.AREditText;
import com.chinalwb.are.styles.ARE_ABS_FreeStyle;

/**
 * All Rights Reserved.
 *
 * @author Wenbin Liu
 */
public class ARE_Style_Record extends ARE_ABS_FreeStyle {

    private AREditText mEditText;
    private ImageView mListNumberImageView;

    public ARE_Style_Record(AREditText editText, ImageView imageView) {
        super(editText.getContext());
        this.mEditText = editText;
        this.mListNumberImageView = imageView;
        setListenerForImageView(this.mListNumberImageView);
    }

    @Override
    public EditText getEditText() {
        return this.mEditText;
    }

    @Override
    public void setListenerForImageView(final ImageView imageView) {
        imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public void applyStyle(Editable editable, int start, int end) {

    }

    @Override
    public ImageView getImageView() {
        return this.mListNumberImageView;
    }

    @Override
    public void setChecked(boolean isChecked) {
    }
}