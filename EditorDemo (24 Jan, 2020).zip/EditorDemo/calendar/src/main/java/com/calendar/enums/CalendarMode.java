package com.calendar.enums;

import com.calendar.interfaces.Experimental;

@Experimental
public enum CalendarMode {

    MONTHS(6),
    WEEKS(1);

    public final int visibleWeeksCount;

    CalendarMode(int visibleWeeksCount) {
        this.visibleWeeksCount = visibleWeeksCount;
    }
}
