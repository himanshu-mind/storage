package com.calendar.interfaces;

import com.calendar.models.CalendarDay;

/**
 * Use math to calculate first days of months by postion from a minium date
 */
public interface DateRangeIndex {

    int getCount();

    int indexOf(CalendarDay day);

    CalendarDay getItem(int position);
}
