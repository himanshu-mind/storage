package com.calendar.models;

import com.calendar.helpers.DayViewFacade;
import com.calendar.interfaces.DayViewDecorator;

public class DecoratorResult {
    public final DayViewDecorator decorator;
    public final DayViewFacade result;

    public DecoratorResult(DayViewDecorator decorator, DayViewFacade result) {
        this.decorator = decorator;
        this.result = result;
    }
}
