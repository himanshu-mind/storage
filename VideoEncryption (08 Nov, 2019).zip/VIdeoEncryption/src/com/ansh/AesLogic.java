package com.ansh;

import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class AesLogic {

	private static final String ALGO = "AES";

	public SecretKey getSecretKey(String password) {
		try {
			byte[] key = password.getBytes("UTF-8");
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = Arrays.copyOf(key, 16);
			return new SecretKeySpec(key, ALGO);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public byte[] encryptData(SecretKey secretKey, byte[] data) {
		try {
			Cipher cipher = Cipher.getInstance(ALGO);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			return cipher.doFinal(data);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public byte[] decryptData(SecretKey secretKey, byte[] encryptedData) {
		try {
			Cipher cipher = Cipher.getInstance(ALGO);
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			return cipher.doFinal(encryptedData);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

}
