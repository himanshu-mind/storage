package com.ansh;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.crypto.SecretKey;

import org.mp4parser.Container;
import org.mp4parser.muxer.Movie;
import org.mp4parser.muxer.Track;
import org.mp4parser.muxer.builder.DefaultMp4Builder;
import org.mp4parser.muxer.container.mp4.MovieCreator;
import org.mp4parser.muxer.tracks.AppendTrack;
import org.mp4parser.muxer.tracks.ClippedTrack;

public class VideoEncryption {

	public static void main(String... args) {

		VideoUtils utils = new VideoUtils();

//		try {
//
//			List<String> list = utils.splitFile();
//
//			List<String> encryptedList = utils.encryptSplitParts(list);
//
//			List<String> decryptedList = utils.decryptEncryptedParts(encryptedList);
//
//			utils.mergeDecryptedParts(decryptedList);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		try {
			Movie movie = MovieCreator.build(utils.samplePath);

			List<Track> tracks = movie.getTracks();

			movie.setTracks(new LinkedList<Track>());
			// remove all tracks we will create new tracks from the old

			double startTime1 = 10;
			double endTime1 = 20;
			double startTime2 = 30;
			double endTime2 = 40;

			boolean timeCorrected = false;

			// Here we try to find a track that has sync samples. Since we can only start
			// decoding
			// at such a sample we SHOULD make sure that the start of the new fragment is
			// exactly
			// such a frame
			for (Track track : tracks) {
				if (track.getSyncSamples() != null && track.getSyncSamples().length > 0) {
					if (timeCorrected) {
						// This exception here could be a false positive in case we have multiple tracks
						// with sync samples at exactly the same positions. E.g. a single movie
						// containing
						// multiple qualities of the same video (Microsoft Smooth Streaming file)

						throw new RuntimeException(
								"The startTime has already been corrected by another track with SyncSample. Not Supported.");
					}
					startTime1 = correctTimeToSyncSample(track, startTime1, false);
					endTime1 = correctTimeToSyncSample(track, endTime1, true);
					startTime2 = correctTimeToSyncSample(track, startTime2, false);
					endTime2 = correctTimeToSyncSample(track, endTime2, true);
					timeCorrected = true;
				}
			}

			for (Track track : tracks) {
				long currentSample = 0;
				double currentTime = 0;
				double lastTime = -1;
				long startSample1 = -1;
				long endSample1 = -1;
				long startSample2 = -1;
				long endSample2 = -1;

				for (int i = 0; i < track.getSampleDurations().length; i++) {
					long delta = track.getSampleDurations()[i];

					if (currentTime > lastTime && currentTime <= startTime1) {
						// current sample is still before the new starttime
						startSample1 = currentSample;
					}
					if (currentTime > lastTime && currentTime <= endTime1) {
						// current sample is after the new start time and still before the new endtime
						endSample1 = currentSample;
					}
					if (currentTime > lastTime && currentTime <= startTime2) {
						// current sample is still before the new starttime
						startSample2 = currentSample;
					}
					if (currentTime > lastTime && currentTime <= endTime2) {
						// current sample is after the new start time and still before the new endtime
						endSample2 = currentSample;
					}
					lastTime = currentTime;
					currentTime += (double) delta / (double) track.getTrackMetaData().getTimescale();
					currentSample++;
				}
				movie.addTrack(new AppendTrack(new ClippedTrack(track, startSample1, endSample1),
						new ClippedTrack(track, startSample2, endSample2)));
			}
			long start1 = System.currentTimeMillis();
			Container out = new DefaultMp4Builder().build(movie);
			long start2 = System.currentTimeMillis();
			FileOutputStream fos = new FileOutputStream(String.format(utils.partsDirectory + "output-%f-%f--%f-%f.mp4",
					startTime1, endTime1, startTime2, endTime2));
			FileChannel fc = fos.getChannel();
			out.writeContainer(fc);

			fc.close();
			fos.close();
			long start3 = System.currentTimeMillis();
			System.err.println("Building IsoFile took : " + (start2 - start1) + "ms");
			System.err.println("Writing IsoFile took  : " + (start3 - start2) + "ms");
			System.err.println("Writing IsoFile speed : "
					+ (new File(String.format("output-%f-%f--%f-%f.mp4", startTime1, endTime1, startTime2, endTime2))
							.length() / (start3 - start2) / 1000)
					+ "MB/s");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		demo();

	}

	private static double correctTimeToSyncSample(Track track, double cutHere, boolean next) {
		double[] timeOfSyncSamples = new double[track.getSyncSamples().length];
		long currentSample = 0;
		double currentTime = 0;
		for (int i = 0; i < track.getSampleDurations().length; i++) {
			long delta = track.getSampleDurations()[i];

			if (Arrays.binarySearch(track.getSyncSamples(), currentSample + 1) >= 0) {
				// samples always start with 1 but we start with zero therefore +1
				timeOfSyncSamples[Arrays.binarySearch(track.getSyncSamples(), currentSample + 1)] = currentTime;
			}
			currentTime += (double) delta / (double) track.getTrackMetaData().getTimescale();
			currentSample++;

		}
		double previous = 0;
		for (double timeOfSyncSample : timeOfSyncSamples) {
			if (timeOfSyncSample > cutHere) {
				if (next) {
					return timeOfSyncSample;
				} else {
					return previous;
				}
			}
			previous = timeOfSyncSample;
		}
		return timeOfSyncSamples[timeOfSyncSamples.length - 1];
	}

	public static void demo() {
		try {
			AesLogic aes = new AesLogic();

			SecretKey secretKey = aes.getSecretKey("Ansh");

			byte[] normalData = Files.readAllBytes(Paths.get("C:\\Users\\himanshupiplani\\Desktop\\OnDuty.mp4"));

			byte[] encryptedBytes = aes.encryptData(secretKey, normalData);

			FileOutputStream os = new FileOutputStream(
					new File("C:\\Users\\himanshupiplani\\Desktop\\OnDutyEncrypted.xyz"));
			os.write(encryptedBytes);
			os.flush();
			os.close();

			byte[] encryptedData = Files.readAllBytes(Paths.get("C:\\Users\\himanshupiplani\\Desktop\\Encrypted.mp4"));

			byte[] decryptedBytes = aes.decryptData(secretKey, encryptedData);

			FileOutputStream os1 = new FileOutputStream(new File("C:\\Users\\himanshupiplani\\Desktop\\Decrypted.mp4"));
			os1.write(decryptedBytes);
			os1.flush();
			os1.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
