package com.ansh;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

public class VideoUtils {

	private AesLogic aes;
	private SecretKey secretKey;

	String samplePath = "C:\\Users\\himanshupiplani\\Desktop\\Sample.mp4";
	String mergedPath = "C:\\Users\\himanshupiplani\\Desktop\\Merged.mp4";

	int mBperSplit = 20;
	String partsDirectory = "C:\\Users\\himanshupiplani\\Desktop\\parts\\";
	String encryptedPartsDirectory = "C:\\Users\\himanshupiplani\\Desktop\\encryptedParts\\";
	String decryptedPartsDirectory = "C:\\Users\\himanshupiplani\\Desktop\\decryptedParts\\";

	public VideoUtils() {
		aes = new AesLogic();
		secretKey = aes.getSecretKey("Ansh");
		
		File pf = new File(partsDirectory);
		if (!pf.exists())
			pf.mkdir();

		File ef = new File(encryptedPartsDirectory);
		if (!ef.exists())
			ef.mkdir();

		File df = new File(decryptedPartsDirectory);
		if (!df.exists())
			df.mkdir();
	}

	public List<String> splitFile() throws IOException {
		System.out.println("Split Started " + new Date());

		if (mBperSplit <= 0) {
			throw new IllegalArgumentException("mBperSplit must be more than zero");
		}

		List<String> partFiles = new ArrayList<>();
		final long sourceSize = new File(samplePath).length();
		final long bytesPerSplit = 1024L * 1024L * mBperSplit;
		final long numSplits = sourceSize / bytesPerSplit;
		long remainingBytes = sourceSize % bytesPerSplit;
		RandomAccessFile raf = new RandomAccessFile(samplePath, "r");
		int maxReadBufferSize = 8 * 1024; // 8KB

		int partNum = 0;
		for (; partNum < numSplits; partNum++) {
			BufferedOutputStream bw = newWriteBuffer(partsDirectory, partNum, partFiles);
			if (bytesPerSplit > maxReadBufferSize) {
				long numReads = bytesPerSplit / maxReadBufferSize;
				long numRemainingRead = bytesPerSplit % maxReadBufferSize;
				for (int i = 0; i < numReads; i++) {
					readWrite(raf, bw, maxReadBufferSize);
				}
				if (numRemainingRead > 0) {
					readWrite(raf, bw, numRemainingRead);
				}
			} else {
				readWrite(raf, bw, bytesPerSplit);
			}
			bw.close();
		}
		if (remainingBytes > 0) {
			BufferedOutputStream bw = newWriteBuffer(partsDirectory, partNum, partFiles);
			readWrite(raf, bw, remainingBytes);
			bw.close();
		}
		raf.close();

		System.out.println("Split Ended " + new Date());

		return partFiles;
	}

	public List<String> encryptSplitParts(List<String> list) throws IOException {
		System.out.println("Encryption Started " + new Date());

		FileOutputStream os;
		
		List<String> encryptedList = new ArrayList<>();
		for (String part : list) {
			File f = new File(part);
			byte[] normalData = Files.readAllBytes(Paths.get(part));
			byte[] encryptedBytes = aes.encryptData(secretKey, normalData);
			File encryptedFile = new File(encryptedPartsDirectory + f.getName());
			encryptedList.add(encryptedFile.getAbsolutePath());
			os = new FileOutputStream(encryptedFile);
			os.write(encryptedBytes);
			os.flush();
			os.close();
		}

		System.out.println("Encryption Ended " + new Date());

		return encryptedList;
	}

	public List<String> decryptEncryptedParts(List<String> encryptedList)
			throws IOException {
		System.out.println("Decryption Started " + new Date());

		FileOutputStream os;
		
		List<String> decryptedList = new ArrayList<>();
		for (String part : encryptedList) {
			File f = new File(part);
			byte[] normalData = Files.readAllBytes(Paths.get(part));
			byte[] decryptedBytes = aes.encryptData(secretKey, normalData);
			File decryptedFile = new File(decryptedPartsDirectory + f.getName());
			decryptedList.add(decryptedFile.getAbsolutePath());
			os = new FileOutputStream(decryptedFile);
			os.write(decryptedBytes);
			os.flush();
			os.close();
		}

		System.out.println("Decryption Ended " + new Date());

		return decryptedList;
	}

	public void mergeDecryptedParts(List<String> decryptedList) throws IOException {
		System.out.println("Merging started " + new Date());

		FileOutputStream fos;
		FileInputStream fis;
		byte[] fileBytes;
		int bytesRead = 0;

		fos = new FileOutputStream(mergedPath, true);
		for (String s : decryptedList) {
			File file = new File(s);
			fis = new FileInputStream(file);
			fileBytes = new byte[(int) file.length()];
			bytesRead = fis.read(fileBytes, 0, (int) file.length());
			assert (bytesRead == fileBytes.length);
			assert (bytesRead == (int) file.length());
			fos.write(fileBytes);
			fos.flush();
			fileBytes = null;
			fis.close();
			fis = null;
		}
		fos.close();
		fos = null;

		System.out.println("Merging Ended " + new Date());
	}

	private BufferedOutputStream newWriteBuffer(String dir, int partNum, List<String> partFiles) throws IOException {
		String partFileName = dir + "Part" + partNum + ".mp4";
		partFiles.add(partFileName);
		return new BufferedOutputStream(new FileOutputStream(partFileName));
	}

	private void readWrite(RandomAccessFile raf, BufferedOutputStream bw, long numBytes) throws IOException {
		byte[] buf = new byte[(int) numBytes];
		int val = raf.read(buf);
		if (val != -1) {
			bw.write(buf);
		}
	}
	
}
